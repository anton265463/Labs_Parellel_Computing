#include <iostream>
#include <fstream>
#include <string>
#include <winsock2.h>
#include <ws2tcpip.h>

#pragma comment(lib, "ws2_32.lib")

#define PORT 8080

void sendResponse(SOCKET clientSocket, const std::string& content, const std::string& contentType = "text/html") {
    std::string httpResponse =
        "HTTP/1.1 200 OK\r\n"
        "Content-Length: " + std::to_string(content.size()) + "\r\n"
        "Content-Type: " + contentType + "\r\n"
        "Connection: close\r\n"
        "\r\n" + content;

    send(clientSocket, httpResponse.c_str(), static_cast<int>(httpResponse.size()), 0);
}

void sendNotFound(SOCKET clientSocket) {
    std::string notFound =
        "HTTP/1.1 404 Not Found\r\n"
        "Content-Length: 13\r\n"
        "Content-Type: text/plain\r\n"
        "Connection: close\r\n"
        "\r\n404 Not Found";
    send(clientSocket, notFound.c_str(), static_cast<int>(notFound.size()), 0);
}

std::string loadFileContent(const std::string& filePath) {
    std::ifstream file(filePath, std::ios::binary);
    if (!file) return "";
    return std::string((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
}

// ������ �������, ��� ������� ���� �� HTTP GET ������
std::string getRequestPath(const std::string& request) {
    size_t methodPos = request.find("GET ");
    if (methodPos == std::string::npos)
        return "";

    size_t pathStart = methodPos + 4; // ���������� "GET "
    size_t pathEnd = request.find(' ', pathStart);
    if (pathEnd == std::string::npos)
        return "";

    return request.substr(pathStart, pathEnd - pathStart);
}

void handleRequest(SOCKET clientSocket) {
    constexpr int bufferSize = 4096;
    char buffer[bufferSize];
    int received = recv(clientSocket, buffer, bufferSize - 1, 0);
    if (received <= 0) {
        closesocket(clientSocket);
        return;
    }

    buffer[received] = '\0';
    std::string request(buffer);

    // �������� ���� �� ������
    std::string path = getRequestPath(request);

    if (path.empty()) {
        sendNotFound(clientSocket);
        closesocket(clientSocket);
        return;
    }

    // ���������� ���� � ��������� ������� ����� (���� �)
    while (path.find("//") != std::string::npos) {
        path.replace(path.find("//"), 2, "/");
    }

    // ��������� ���� �� ������
    std::string requestedFile;
    if (path == "/" || path == "index.html") {
        requestedFile = "index.html";
    }
    else if (path == "page2.html") {
        requestedFile = "page2.html";
    }
    else {
        sendNotFound(clientSocket);
        closesocket(clientSocket);
        return;
    }

    std::string content = loadFileContent(requestedFile);
    if (content.empty()) {
        sendNotFound(clientSocket);
    }
    else {
        sendResponse(clientSocket, content);
    }

    closesocket(clientSocket);
}

int main() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "WSAStartup failed.\n";
        return 1;
    }

    SOCKET serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == INVALID_SOCKET) {
        std::cerr << "Socket creation failed\n";
        WSACleanup();
        return 1;
    }

    sockaddr_in serverAddr{};
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(PORT);

    if (bind(serverSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        std::cerr << "Bind failed\n";
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    if (listen(serverSocket, 5) == SOCKET_ERROR) {
        std::cerr << "Listen failed\n";
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    std::cout << "Server listening on port " << PORT << "...\n";

    while (true) {
        sockaddr_in clientAddr{};
        int clientAddrLen = sizeof(clientAddr);
        SOCKET clientSocket = accept(serverSocket, (sockaddr*)&clientAddr, &clientAddrLen);

        if (clientSocket == INVALID_SOCKET) {
            std::cerr << "Accept failed\n";
            continue;
        }

        char clientIP[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &(clientAddr.sin_addr), clientIP, INET_ADDRSTRLEN);
        std::cout << "Connection from " << clientIP << ":" << ntohs(clientAddr.sin_port) << "\n";

        handleRequest(clientSocket);
    }

    closesocket(serverSocket);
    WSACleanup();
    return 0;
}
