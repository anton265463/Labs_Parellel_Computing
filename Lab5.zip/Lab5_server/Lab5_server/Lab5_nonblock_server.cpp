#include <iostream>
#include <fstream>
#include <string>
#include <winsock2.h>
#include <ws2tcpip.h>

#pragma comment(lib, "ws2_32.lib")

#define PORT 8080
#define MAX_BUFFER_SIZE 4096

struct ClientContext {
    SOCKET socket;
    OVERLAPPED overlapped;
    WSABUF dataBuffer;
    char buffer[MAX_BUFFER_SIZE];
};

void printLastError(const char* msg) {
    int errCode = WSAGetLastError();
    std::cerr << msg << " Error code: " << errCode << std::endl;
}

void sendResponse(SOCKET clientSocket, const std::string& content, const std::string& contentType = "text/html") {
    std::string httpResponse =
        "HTTP/1.1 200 OK\r\n"
        "Content-Length: " + std::to_string(content.size()) + "\r\n"
        "Content-Type: " + contentType + "\r\n"
        "Connection: close\r\n"
        "\r\n" + content;

    send(clientSocket, httpResponse.c_str(), static_cast<int>(httpResponse.size()), 0);
}

void sendNotFound(SOCKET clientSocket) {
    std::string notFound =
        "HTTP/1.1 404 Not Found\r\n"
        "Content-Length: 13\r\n"
        "Content-Type: text/plain\r\n"
        "Connection: close\r\n"
        "\r\n404 Not Found";
    send(clientSocket, notFound.c_str(), static_cast<int>(notFound.size()), 0);
}

std::string loadFileContent(const std::string& filePath) {
    std::ifstream file(filePath, std::ios::binary);
    if (!file) return "";
    return std::string((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
}

std::string getRequestPath(const std::string& request) {
    size_t methodPos = request.find("GET ");
    if (methodPos == std::string::npos)
        return "";

    size_t pathStart = methodPos + 4;
    size_t pathEnd = request.find(' ', pathStart);
    if (pathEnd == std::string::npos)
        return "";

    return request.substr(pathStart, pathEnd - pathStart);
}

void handleRequest(ClientContext* clientContext) {
    std::string request(clientContext->buffer);

    std::string path = getRequestPath(request);
    if (path.empty()) {
        sendNotFound(clientContext->socket);
        closesocket(clientContext->socket);
        delete clientContext;
        return;
    }

    while (path.find("//") != std::string::npos) {
        path.replace(path.find("//"), 2, "/");
    }

    std::string requestedFile;
    if (path == "/" || path == "/index.html") {
        requestedFile = "index.html";
    }
    else if (path == "/page2.html") {
        requestedFile = "page2.html";
    }
    else {
        sendNotFound(clientContext->socket);
        closesocket(clientContext->socket);
        delete clientContext;
        return;
    }

    std::string content = loadFileContent(requestedFile);
    if (content.empty()) {
        sendNotFound(clientContext->socket);
    }
    else {
        sendResponse(clientContext->socket, content);
    }

    closesocket(clientContext->socket);
    delete clientContext;
}

void CALLBACK WorkerRoutine(DWORD errorCode, DWORD bytesTransferred, LPWSAOVERLAPPED overlapped, DWORD flags) {
    ClientContext* clientContext = reinterpret_cast<ClientContext*>(overlapped);

    if (errorCode != 0 || bytesTransferred == 0) {
        closesocket(clientContext->socket);
        delete clientContext;
        return;
    }

    clientContext->buffer[bytesTransferred] = '\0';
    handleRequest(clientContext);
}

int main() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "WSAStartup failed.\n";
        return 1;
    }

    SOCKET serverSocket = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, WSA_FLAG_OVERLAPPED);
    if (serverSocket == INVALID_SOCKET) {
        printLastError("Socket creation failed.");
        WSACleanup();
        return 1;
    }

    sockaddr_in serverAddr{};
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(PORT);

    if (bind(serverSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        printLastError("Bind failed.");
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    if (listen(serverSocket, SOMAXCONN) == SOCKET_ERROR) {
        printLastError("Listen failed.");
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    std::cout << "Server listening on port " << PORT << "...\n";

    while (true) {
        sockaddr_in clientAddr{};
        int clientAddrLen = sizeof(clientAddr);
        ClientContext* clientContext = new ClientContext{};
        clientContext->socket = accept(serverSocket, (sockaddr*)&clientAddr, &clientAddrLen);

        if (clientContext->socket == INVALID_SOCKET) {
            printLastError("Accept failed.");
            delete clientContext;
            continue;
        }

        char clientIP[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &(clientAddr.sin_addr), clientIP, INET_ADDRSTRLEN);
        std::cout << "Connection from " << clientIP << ":" << ntohs(clientAddr.sin_port) << "\n";

        ZeroMemory(&clientContext->overlapped, sizeof(OVERLAPPED));
        clientContext->dataBuffer.len = MAX_BUFFER_SIZE - 1;
        clientContext->dataBuffer.buf = clientContext->buffer;

        DWORD flags = 0;
        DWORD bytesReceived = 0;
        int res = WSARecv(clientContext->socket, &clientContext->dataBuffer, 1, &bytesReceived, &flags, &clientContext->overlapped, WorkerRoutine);
        if (res == SOCKET_ERROR) {
            int lastErr = WSAGetLastError();
            if (lastErr != WSA_IO_PENDING) {
                printLastError("WSARecv failed.");
                closesocket(clientContext->socket);
                delete clientContext;
            }
        }
    }

    closesocket(serverSocket);
    WSACleanup();
    return 0;
}
